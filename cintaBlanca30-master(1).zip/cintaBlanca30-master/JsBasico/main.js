// alert("Hola, si funciono!!!!")

// let numero = 10
// let texto = "Hola!"
// let booleano = true
// let array = []
// let object = {}

// + - / * %

// let num1 = 100
// let num2 = 500

// //let result = num1 + num2

// console.log(num1 + num2)

// console.log(numero)


// let saludo = "Hola!"
// let name = "Pepe"
// console.log(saludo)
// console.log(name)

// console.log( saludo + " " + name)

// let entra = prompt("Ingrese su nombre")

// console.log(entra)

//________________
//Challenge:
// Van a preguntar al usuario Nombre, Direccion, año de nac. y con ese su edad
// y mostrar en la consola en una linea

// let name = prompt("Nombre")
// let direc = prompt("Canton")
// let año = prompt("Año de Nacimiento")
// let act = 2019 - año

// console.log("Nombre: "+ name + " "+ "Direccion: " + direc + " " +"Edad: "+ act )


//Arreglos:

// let array = [10, 20, 50 , 100]
// let animals = ["perrito", "gatito", "perico"]

// animals[3] = "hipopotamo"

// animals.push("cocodrilo")
// animals.push("nutria")

// // animals.pop()

// let str = "Hola mundo , como estas"
// let search = str.indexOf("mundo")

// console.log(search)


// console.log(animals)

//  let animals = ["perrito", "gatito", "perico"]

//  animals.splice(0,1)

//  console.log(animals)


// Hacer un arreglod de  5 colores y añadir 2 con push
// let colors = ["negro","blanco","verder","rosa","azul"]

// colors.push("gris")
// colors.push("morado")
// console.log(colors)

//Hacer un arreglo de 3 G.M, sumar 3 con push, y borrae el elemento 0 y 1

// let gm = ["perreke", "banda","duranguense"]

// gm.push("merol")
// gm.push("indie")
// gm.push("house")

// gm.splice(0,2)

// console.log(gm)


let array = ["a","b","c","d","e","f","g","h","i","j"]

let all = array.indexOf("c")
console.log(all)