//Preguntar al usuario un numero, evaluar si es par o impar, mostrarlo en la consola

// let numero = prompt("Ingresa un numero")

// if(numero % 2 === 0){
//     console.log("Es par :)")
// }else{
//     console.log("Es impar :(")
// }

// if(numero / 2 === 0){
//     console.log("Es par :)")
// }else{
//     console.log("Es impar :(")
// }

// jugador1 = prompt("Player 1 : Escribe piedra, papel o tijera");
// jugador2 = prompt("Player 2 : Escribe piedra papel o tijera");

// if (jugador2 === "piedra" || jugador2 === "papel" || jugador2 === "tijera" && jugador1 === "piedra" || jugador1 === "papel" || jugador1 === "tijera" ){
//     if (jugador1 === "piedra") {
//         if (jugador2 === "papel") {
//             console.log("Papel le gana a piedra. Ganó el jugador 2.")
//         } else if (jugador2 === "piedra") {
//             console.log("Hubo un empate")
//         } else{
//             console.log("Piedra le gana a tijera. Ganó el jugador 1.")
//         }
//     } else if (jugador1 === "papel") { 
//         if (jugador2 === "tijera") {
//             console.log("Tijera le gana a papel. Ganó el jugador 2.")
//         } else if (jugador2 === "papel") {
//             console.log("Hubo un empate")
//         } else{
//             console.log("Papel le gana a piedra. Ganó el jugador 1")
//         }
//     } else if (jugador1 === "tijera"){
//         if (jugador2 === "piedra") {
//             console.log("Piedra le gana a tijera. Ganó el jugador 2")
//         } else if (jugador2 === "tijera") {
//             console.log("Hubo un empate.")
//         } else{
//             console.log("Tijera le gana a papel. Ganó el jugador 1")
//         }
//     } 
// } else {
//     console.log("Ambos jugadores necesitan escribir piedra, papel o tijera")
// }

