// //Ciclo For

// for(let i = 0; i <= 100; i = i +1){
//     //console.log(i)
// }
// // ciclo del 500 al 1000 de 2 en 2
// for(let e = 500; e <= 1000; e = e+2){
//     //console.log(e)
// }
// // ciclo del 100 al 0 de -3 
// for(let r = 100;r >= 0; r = r -3){
//     // console.log(r)
// }
// // cilo de 1 al 50 de 10 en 10
// // for(let t = 0; t<=50; t =t+ 10 ){
// //     console.log(t)
// // }


// //Challenge---------------------------->
// // usando el ciclo for, evalular los numeros del 1-100 y decir si cuales son pares e impares

// // for(let i = 0; i <= 100; i++){
// //     if(i % 2 === 0){
// //         console.log(i + " es par ")
// //     }else{
// //         console.log(i + " es impar ")
// //     }
// // }

// //Numero del 1-100
// // Si son divisibles entre 3 -> Fizz
// // Si son divisibles entre 5 -> Buzz
// // Si sin divisibles entre 5 y 3 -> FizzBuzz

// // for(let i = 0; i <= 100; i = i +1){
// //     if(i % 3 === 0 && i % 5 === 0){
// //         console.log(i + " FizzBuzz")
// //     }else if (i % 5 === 0){
// //             console.log(i + " Buzz")
// //     }else if(i % 3 === 0){
// //         console.log(i + " Fizz")
// //     }else{
// //         console.log(i)
// //     }
// // }

// let array = ["a","b","c","d","e","f","g","h"]

// for(let i = 0; i < array.length ; i ++){
//     console.log(array[i])

// }

//Con el ciclo for, hacer las tablas de multiplicar del 1-10
// Mostrar en consola

// 1 x 1 = 1
// 1 x 2 = 2...
// 1 x 10 = 10...
// 10 x 10 = 100

// for(let a = 1 ; a <= 10; a++){
//     for(let b = 1; b <= 10; b++){
//         console.log(a + " * "+ b + " =" + a*b)
//     }

// }



//Arreglo de 10 
// Pushear 5 elementos y iterar ese arreglo

// let array = []

// for(let i = 1; i <= 150; i++){

//     array.push(i-1)

// }

// for(let i = 0; i < array.length; i++){
//      console.log(array[i])


// }


// console.log(array)