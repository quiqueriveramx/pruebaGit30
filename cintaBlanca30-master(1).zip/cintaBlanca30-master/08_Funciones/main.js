
// function sum (a,b){

//     return a + b 

// }

// function res (c,d){
//     return c -d
// }


// const sum  = (a,b) =>{

//         return a+b
// }

// console.log(sum(5,5))


// Arrow fuction que multiplique 3 numero y otra que divida 2 numeros

// Challenge------------------_>>>>>
// Funcion que calcule el area de un cuadrado y otra el area de un rectagulo


//Funcion que reciba el numero, y mostar el factorial de un numero(10)


// const factorial = (x) => {

//     let resultado = 1
//     for(let i = 1; i <= x; i++){
//         resultado = resultado * i
//     }
//         console.log(resultado)
// }

// factorial(3);